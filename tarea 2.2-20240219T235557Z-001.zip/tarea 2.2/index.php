<html>
<head></head>
<body>
<h1>772. 0 Multiplicacion basica</h1>

<h2>Descripción</h2>
Dado un valor real a quieres resolver una serie de ecuaciones hasta obtener el valor de z.


<h2>Entrada</h2>
Un real a.

<h2>Salida</h2>
Un real que sea el valor de z impreso con tres puntos decimales

<h2>Ejemplo</h2>

<?php

// Función para calcular el valor de z dado un valor de a
function calcularZ($a) {
    $x = 3 * $a + 15;
    $y = ($x + 3) / ($x + 1);
    $z = (5 * $x + 7 * $y) / ($a * $x * $y);
    return $z;
}

// Valor de entrada para a (puedes cambiarlo según sea necesario)
$a = 2.5;

// Calcular el valor de z
$z = calcularZ($a);

// Imprimir el resultado con tres puntos decimales
echo number_format($z, 3, '.', '');

?>



</body>
</html>